The Microsoft ML for Apache Spark package provides a python API to scala.


